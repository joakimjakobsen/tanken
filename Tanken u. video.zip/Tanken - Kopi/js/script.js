var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/; /*Information om brug af regex fundet via https://www.simplilearn.com/tutorials/javascript-tutorial/email-validation-in-javascript */
var userNameInput = false;
var userMailInput = false;
var firsttry = true;

function inputCheck() {
    var userName = document.getElementById("name").value; /* hent hvad der er indtastet i inputfeltet for navn*/
    var userMail = document.getElementById("email").value; /* hent hvad der er indtastet i inputfeltet for email*/
  
    if (userName.length < 1) {
        alert("Hov husk at skrive dit navn"); /* Giv feedback til bruger om at de mangler at skrive navn */
    } else {
        userNameInput = true;
    }

    if (userMail.match(validRegex)) {   /* tjek om det er en mail adresse som er skrevet. Information om brug af regex er fundet via https://www.simplilearn.com/tutorials/javascript-tutorial/email-validation-in-javascript */
        userMailInput = true;
    } else {
        userMailInput = false;
        alert("Hmm... tjek om emailen er skrevet rigtigt"); /* Giv feedback til bruger om at de mangler at skrive email for at fortsætte */
    }

    if (userMailInput == true && userNameInput==true) { /* hvis der er skrevet et navn og en korrekt mail vil vi gerne gemme det så vi kan sende en mail til dem. */
        sessionStorage.setItem('user_name', userName);
        sessionStorage.setItem('user_mail', userMail);
        rotateFunction(); /* Aktiverer hjulet som skal spinne */
    }
}

/* inspireret af https://workshops.hackclub.com/spinning_wheel/ */
function rotateFunction() { 
    if (firsttry == true) { /* Sørger for man kun får ét spin (tager dog ikke højde for hvis nu en ny med en anden mail i samme session også vil spille) */
        var min = 2000; /* definerer minimum rotering */
        var max = 10000; /* definerer maximum rotering */
        var deg = Math.floor(Math.random() * (max - min)) + min; /* Math.floor() giver et tilfældigt tal fra 0 til 9999 som hjulet skal dreje. */
        document.getElementById('wheel').style.transform = "rotate(" + deg + "deg)"; /* tilføjer den ønskede rotation til hjulet. */
    
        setTimeout (function() {
            var prizes = ["1 x BMO (altså en Bolle Med Ost)! Din præmie er sendt på email", "1 x Ceres Top! Din præmie er sendt på email", "2 x Vaffelis! Din præmie er sendt på email", "1 x Filterkaffe! Din præmie er sendt på email", "en kæmpe highfive næste gang du kommer forbi!"];
            const random = Math.floor(Math.random() * prizes.length); /* giver et tilfældigt tal fra 0 til 4 fordi længden af vores array er 5*/
            console.log(prizes[random]); /* konsollen kan tjekkes for at se hvilken præmie der er blevet trukket */
        
            Swal.fire({ /* dette er en popup modal skabelon fra sweetalert2, som vi har tilpasset til vores formål link: https://sweetalert2.github.io/#color */
                title: 'Sprød asfalt!',
                text: 'Du har lige vundet ' + prizes[random], 
                imageUrl: "media/kiosk.png",
                imageWidth: 400,
                imageHeight: 200,
                imageAlt: 'Custom image',
            });
        }, 4000);

        firsttry = false;

    } else {
        alert ("Der er desværre kun ét forsøg pr. kunde");
    }
}



