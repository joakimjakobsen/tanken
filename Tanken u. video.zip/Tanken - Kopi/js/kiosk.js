
document.getElementById("stempelknap").addEventListener("click", scroll1);
document.getElementById("merchknap").addEventListener("click", scroll2);
document.getElementById("gaveknap").addEventListener("click", scroll3);

function scroll1() {
    var stempelkort = document.getElementById('stempelkort-section');

    stempelkort.scrollIntoView({  /* Få sektionen til at rulle ind så den er synlig i viewporten */
        behavior: "smooth",
        block: "start",
        inline: "nearest"
    });
}

function scroll2() {
    var merch = document.getElementById('merch');

    merch.scrollIntoView({
        behavior: "smooth",
        block: "start",
        inline: "nearest"
    });
}

function scroll3() {
    var gave = document.getElementById('gave');

    gave.scrollIntoView({
        behavior: "smooth",
        block: "start",
        inline: "nearest"
    });
}